package com.stickheroap.stickheroap;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class RectangleLengthExtension extends Application {

    private AnchorPane root;
    private Rectangle rectangle;
    private double initialWidth = 50.0; // Initial width of the rectangle

    private boolean stickExtended = false;
    private Timeline timeline;

    private boolean isGrowing = false;
    private boolean isGrowingFinished = false;

    private int frequency1=0;
    private int frequency2=0;

    @Override
    public void start(Stage primaryStage) {

        System.out.println("Application Started");
        root = new AnchorPane();
        Scene scene = new Scene(root, 600, 400);

        Rectangle rectangle1 = new Rectangle(100, 10, 50, 50);
        rectangle1.setFill(Color.RED);
        root.getChildren().add(rectangle1);

        rectangle = new Rectangle(172, 251, 3, 1);
        rectangle.setFill(Color.BLUE);

        root.getChildren().add(rectangle);

        // Set up a Timeline animation to extend the length of the rectangle
        timeline = new Timeline(
                new KeyFrame(Duration.millis(50), e -> extendRectangle())
        );
        timeline.setCycleCount(Animation.INDEFINITE);

        // Add mouse pressed and released event handlers
        root.setOnMousePressed(this::handleMousePressed);
        root.setOnMouseReleased(this::handleMouseReleased);

        primaryStage.setTitle("Rectangle Length Extension");
        primaryStage.setScene(scene);
        primaryStage.show();

        timeline.play();
    }

    private void handleStick() {
        if (isGrowing && rectangle != null && !isGrowingFinished) {
            rectangle.setHeight(rectangle.getHeight() + 1);
        }
    }

    private void extendRectangle() {
        double newHeight = rectangle.getHeight() + 5.0;
        rectangle.setHeight(newHeight);
//        rectangle.setY(rectangle.getY() - 5.0);
        rectangle.setY(rectangle.getY() - 1);
    }

    private void handleMousePressed(MouseEvent event) {

//        stickExtended = true;
        // Start the timeline when the mouse is pressed
        if(stickExtended==false) {

            System.out.println("hello");
            timeline.play();
            stickExtended = true;
        }
        else{
            System.out.println("stick extended flag is set to true");
        }
    }

    private void handleMouseReleased(MouseEvent event) {
        // Stop the timeline when the mouse is released
        timeline.stop();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
